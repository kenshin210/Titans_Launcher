"""About Device settings pages."""
