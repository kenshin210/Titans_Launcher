"""Launcher dialog components."""
