"""Launcher user-interface components."""
