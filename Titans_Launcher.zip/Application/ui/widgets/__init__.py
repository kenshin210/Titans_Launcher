"""Reusable launcher widgets."""
